#include "esp_http_server.h"
#include "esp_timer.h"
#include "esp_camera.h"
#include "img_converters.h"
#include "Arduino.h"

// 引用 Main.ino 的全局变量
extern float global_sht_temp;
extern float global_sht_hum;
extern String global_weather_json;

// Web 服务器句柄
httpd_handle_t stream_httpd = NULL;
httpd_handle_t camera_httpd = NULL;

// 视频流定义
#define PART_BOUNDARY "123456789000000000000987654321"
static const char* _STREAM_CONTENT_TYPE = "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char* _STREAM_BOUNDARY = "\r\n--" PART_BOUNDARY "\r\n";
static const char* _STREAM_PART = "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

// ==================== HTML 页面内容 ====================
const char index_html[] = R"rawliteral(
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>ESP32 Monitor</title>
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/smoothie@1.34.0/smoothie.js"></script>
  <style>
    body { margin: 0; display: flex; height: 100vh; background: #121212; color: #e0e0e0; font-family: sans-serif; overflow: hidden; }
    
    /* 左侧边栏 */
    .sidebar { width: 320px; background: #1e1e1e; border-right: 1px solid #333; padding: 15px; display: flex; flex-direction: column; gap: 15px; overflow-y: auto; z-index: 2; }
    .card { background: #2d2d2d; border-radius: 8px; padding: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.3); }
    .card h2 { margin: 0 0 8px 0; font-size: 0.95rem; color: #aaa; border-bottom: 1px solid #444; padding-bottom: 4px; }
    .row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px; }
    .val { font-size: 1.1rem; font-weight: bold; color: #fff; }
    .unit { font-size: 0.8rem; color: #777; margin-left: 2px; }
    .t-color { color: #ff4040; } .h-color { color: #40c4ff; }
    .notice { font-size: 0.75rem; color: #888; margin-top: 8px; font-style: italic; }

    /* 曲线图 Canvas 样式 */
    canvas { width: 100%; height: 60px; display: block; margin-top: 5px; border-radius: 4px; background: #222; }

    /* 右侧主视图区 */
    .main-view { flex: 1; background: #000; display: flex; justify-content: center; align-items: center; position: relative; }
    figure { margin: 0; padding: 0; width: 100%; height: 100%; display: flex; justify-content: center; align-items: center; }
    .image-container { position: relative; max-width: 100%; max-height: 100%; display: flex; }
    .image-container.hidden { display: none; }
    img#stream { max-width: 100%; max-height: 100vh; object-fit: contain; box-shadow: 0 0 20px rgba(0,0,0,0.8); }
    .close { position: absolute; top: 10px; right: 10px; background: rgba(255, 0, 0, 0.7); color: white; width: 30px; height: 30px; text-align: center; line-height: 30px; border-radius: 50%; cursor: pointer; font-weight: bold; z-index: 10; }
    #reload-btn { display: none; padding: 10px 20px; background: #333; color: #fff; border: 1px solid #555; cursor: pointer; border-radius: 5px; }
  </style>
</head>
<body>

  <div class="sidebar">
    <div style="text-align:center; margin-bottom:5px;">
      <h1 style="margin:0; font-size:1.2rem;">环境监控系统</h1>
      <div style="font-size:0.7rem; color:#666;">ESP32-S3 + OV5640 + SHT45</div>
    </div>

    <div class="card">
      <h2>SHT45 实时数据</h2>
      <div class="row"><span>温度</span><div><span id="loc_t" class="val t-color">--</span><span class="unit">°C</span></div></div>
      <canvas id="chart_temp" width="280" height="60"></canvas>
      
      <div style="height:10px;"></div> <div class="row"><span>湿度</span><div><span id="loc_h" class="val h-color">--</span><span class="unit">%</span></div></div>
      <canvas id="chart_hum" width="280" height="60"></canvas>
    </div>

    <div class="card">
      <h2>北京天气 (<span id="w_type">--</span>)</h2>
      <div class="row"><span>气温</span><div><span id="w_temp" class="val">--</span><span class="unit">°C</span></div></div>
      <div class="row"><span>湿度</span><div><span id="w_shidu" class="val">--</span></div></div>
      <div class="row"><span>空气</span><div><span id="w_qual" class="val">--</span><span id="w_pm" class="unit">PM2.5: --</span></div></div>
      <div class="notice" id="w_note">正在获取数据...</div>
    </div>
    
    <div style="text-align:center; font-size:0.7rem; color:#444; margin-top:auto;">
      <div id="status_msg">System Ready</div>
    </div>
  </div>

  <div class="main-view">
    <button id="reload-btn" onclick="startStream()">打开视频流</button>
    <figure>
      <div id="stream-container" class="image-container">
        <div class="close" id="close-stream" onclick="stopStream()">×</div>
        <img id="stream" src="">
      </div>
    </figure>
  </div>

<script>
  let streamUrl = "";
  
  // --- 图表初始化 ---
  // 1. 定义时间序列
  var lineTemp = new TimeSeries();
  var lineHum = new TimeSeries();

  // 2. 配置温度图表样式
  var chartTemp = new SmoothieChart({
    responsive: true,                 // 自适应宽度
    millisPerPixel: 50,               // 滚动速度 (越小越快)
    grid: { fillStyle: '#222', strokeStyle: '#333', verticalSections: 0, borderVisible: false },
    labels: { disabled: true },       // 隐藏坐标轴文字以节省空间
    maxValue: 50, minValue: 0         // 固定温度范围(可选)
  });
  
  // 3. 配置湿度图表样式
  var chartHum = new SmoothieChart({
    responsive: true,
    millisPerPixel: 50,
    grid: { fillStyle: '#222', strokeStyle: '#333', verticalSections: 0, borderVisible: false },
    labels: { disabled: true },
    maxValue: 100, minValue: 0
  });

  // 4. 将线条绑定到 Canvas
  // 温度线：红色，半透明填充
  chartTemp.addTimeSeries(lineTemp, { strokeStyle: '#ff4040', fillStyle: 'rgba(255, 64, 64, 0.2)', lineWidth: 2 });
  // 湿度线：蓝色，半透明填充
  chartHum.addTimeSeries(lineHum, { strokeStyle: '#40c4ff', fillStyle: 'rgba(64, 196, 255, 0.2)', lineWidth: 2 });

  // 5. 开始渲染
  chartTemp.streamTo(document.getElementById("chart_temp"), 1000); // 1000ms 延迟缓冲让曲线更平滑
  chartHum.streamTo(document.getElementById("chart_hum"), 1000);

  // --- 核心逻辑 ---

  window.onload = function() {
    const streamPort = 81;
    streamUrl = "http://" + window.location.hostname + ":" + streamPort + "/stream";
    startStream();
  };

  function startStream() {
    const img = document.getElementById("stream");
    const container = document.getElementById("stream-container");
    const btn = document.getElementById("reload-btn");
    img.src = streamUrl;
    container.classList.remove("hidden");
    btn.style.display = "none";
  }

  function stopStream() {
    const img = document.getElementById("stream");
    const container = document.getElementById("stream-container");
    const btn = document.getElementById("reload-btn");
    window.stop();
    img.src = "";
    container.classList.add("hidden");
    btn.style.display = "block";
  }

  // 获取 SHT45 数据并推送到图表
  function fetchEnv() {
    fetch('/env')
      .then(r => r.json())
      .then(d => {
        // 更新数字显示
        document.getElementById('loc_t').innerText = d.temp.toFixed(1);
        document.getElementById('loc_h').innerText = d.hum.toFixed(1);
        
        // [关键] 将数据推送到图表时间序列
        var now = new Date().getTime();
        lineTemp.append(now, d.temp);
        lineHum.append(now, d.hum);
      })
      .catch(e => console.log("Env err"));
  }

  // 获取天气
  function fetchWeather() {
    fetch('/weather_proxy')
      .then(r => r.json())
      .then(json => {
        if(json.status != 200) return;
        const d = json.data;
        document.getElementById('w_temp').innerText = d.wendu;
        document.getElementById('w_shidu').innerText = d.shidu;
        document.getElementById('w_qual').innerText = d.quality;
        document.getElementById('w_pm').innerText = "PM2.5: " + d.pm25;
        
        const today = d.forecast[0];
        document.getElementById('w_type').innerText = today.type;
        document.getElementById('w_note').innerText = today.notice;
        
        document.getElementById('status_msg').innerText = "Updated: " + json.time.split(' ')[1];
      })
      .catch(e => console.log("Weather err"));
  }

  setInterval(fetchEnv, 1000); // 1秒刷新一次数据和图表
  fetchEnv();
  
  setInterval(fetchWeather, 60000);
  fetchWeather();
</script>
</body>
</html>
)rawliteral";

// ==================== 接口处理函数 ====================

static esp_err_t index_handler(httpd_req_t *req) {
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, index_html, HTTPD_RESP_USE_STRLEN);
}

static esp_err_t env_handler(httpd_req_t *req) {
  char json[64];
  snprintf(json, sizeof(json), "{\"temp\":%.2f,\"hum\":%.2f}", global_sht_temp, global_sht_hum);
  httpd_resp_set_type(req, "application/json");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  return httpd_resp_send(req, json, strlen(json));
}

static esp_err_t weather_proxy_handler(httpd_req_t *req) {
  httpd_resp_set_type(req, "application/json");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  return httpd_resp_send(req, global_weather_json.c_str(), global_weather_json.length());
}

// 视频流处理 (81端口)
static esp_err_t stream_handler(httpd_req_t *req) {
  camera_fb_t *fb = NULL;
  esp_err_t res = ESP_OK;
  size_t _jpg_buf_len = 0;
  uint8_t *_jpg_buf = NULL;
  char part_buf[64];

  res = httpd_resp_set_type(req, _STREAM_CONTENT_TYPE);
  if (res != ESP_OK) return res;

  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

  while (true) {
    fb = esp_camera_fb_get();
    if (!fb) {
      Serial.println("Camera capture failed");
      res = ESP_FAIL;
    } else {
      if (fb->format != PIXFORMAT_JPEG) {
        bool jpeg_converted = frame2jpg(fb, 80, &_jpg_buf, &_jpg_buf_len);
        esp_camera_fb_return(fb);
        fb = NULL;
        if (!jpeg_converted) {
          Serial.println("JPEG compression failed");
          res = ESP_FAIL;
        }
      } else {
        _jpg_buf_len = fb->len;
        _jpg_buf = fb->buf;
      }
    }
    
    if (res == ESP_OK) {
      res = httpd_resp_send_chunk(req, _STREAM_BOUNDARY, strlen(_STREAM_BOUNDARY));
    }
    if (res == ESP_OK) {
      size_t hlen = snprintf(part_buf, 64, _STREAM_PART, _jpg_buf_len);
      res = httpd_resp_send_chunk(req, part_buf, hlen);
    }
    if (res == ESP_OK) {
      res = httpd_resp_send_chunk(req, (const char *)_jpg_buf, _jpg_buf_len);
    }
    
    if (fb) {
      esp_camera_fb_return(fb);
      fb = NULL;
      _jpg_buf = NULL;
    } else if (_jpg_buf) {
      free(_jpg_buf);
      _jpg_buf = NULL;
    }
    
    if (res != ESP_OK) break;
  }
  return res;
}

// ==================== 启动服务器 ====================
void startCameraServer() {
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.server_port = 80; 

  httpd_uri_t index_uri = {
    .uri       = "/",
    .method    = HTTP_GET,
    .handler   = index_handler,
    .user_ctx  = NULL
  };

  httpd_uri_t env_uri = {
    .uri       = "/env",
    .method    = HTTP_GET,
    .handler   = env_handler,
    .user_ctx  = NULL
  };

  httpd_uri_t weather_uri = {
    .uri       = "/weather_proxy",
    .method    = HTTP_GET,
    .handler   = weather_proxy_handler,
    .user_ctx  = NULL
  };

  httpd_uri_t stream_uri = {
    .uri       = "/stream",
    .method    = HTTP_GET,
    .handler   = stream_handler,
    .user_ctx  = NULL
  };

  Serial.printf("Starting WEB server on port: '%d'\n", config.server_port);
  if (httpd_start(&camera_httpd, &config) == ESP_OK) {
    httpd_register_uri_handler(camera_httpd, &index_uri);
    httpd_register_uri_handler(camera_httpd, &env_uri);
    httpd_register_uri_handler(camera_httpd, &weather_uri);
  }

  config.server_port += 1;
  config.ctrl_port += 1;
  Serial.printf("Starting STREAM server on port: '%d'\n", config.server_port);
  if (httpd_start(&stream_httpd, &config) == ESP_OK) {
    httpd_register_uri_handler(stream_httpd, &stream_uri);
  }
}

void setupLedFlash(int pin) {}