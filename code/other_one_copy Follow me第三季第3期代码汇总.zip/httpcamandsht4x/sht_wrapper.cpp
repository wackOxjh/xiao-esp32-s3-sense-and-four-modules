#include "sht_wrapper.h"
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_SHT4x.h> // 在这里引用库，避开 esp_camera.h



Adafruit_SHT4x sht4 = Adafruit_SHT4x();

void initSHT45_Lib() {

  if (!sht4.begin()) {
    Serial.println("SHT45 Error: Sensor not found via Wrapper!");
  } else {
    Serial.println("SHT45 OK: Sensor initialized via Wrapper.");
    sht4.setPrecision(SHT4X_HIGH_PRECISION);
    sht4.setHeater(SHT4X_NO_HEATER);
  }
}

bool readSHT45_Lib(float *temp, float *hum) {
  sensors_event_t humidity, temperature;
  // getEvent 是 Adafruit 库的标准函数
  if (sht4.getEvent(&humidity, &temperature)) {
    *temp = temperature.temperature;
    *hum = humidity.relative_humidity;
    return true;
  }
  return false;
}