#ifndef SHT_WRAPPER_H
#define SHT_WRAPPER_H

// 只声明函数，不引用任何库，防止冲突
void initSHT45_Lib();
bool readSHT45_Lib(float *temp, float *hum);

#endif